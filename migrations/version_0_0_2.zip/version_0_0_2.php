<?php
/**
*
* @package phpBB Extension - My test
* @copyright (c) 2013 phpBB Group
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace Sumanai\simplechat\migrations;

class version_0_0_2 extends \phpbb\db\migration\migration
{
    /*public function effectively_installed()
    {
        return isset($this->config['simplechat_version']) && version_compare($this->config['simplechat_version'], '0.0.2', '>=');
    }
    static public function depends_on()
	{
			return array('\Sumanai\simplechat\migrations\version_0_0_1');
            //return array('\phpbb\db\migration\data\v310\dev');
	}
*/
	public function update_data()
	{
		return array(
			// Current version
			array('config.add', array('simplechat_version', '0.0.2')),
			array('config.add', array('show_greeting', '')),
			// Add new module
            
            array('module.add', array(
                'acp',
                'ACP_CAT_DOT_MODS',
                'ACP_SIMPLECHAT'
            )),
            array('module.add', array(
                'acp',
                'ACP_SIMPLECHAT',
                array(
                    'module_basename'    => 'simplechat',
                    'modes'              => array('settings', 'features'),
                ),
            )),            
            /*
    	   // Add permissions
            array('permission.add', array('u_siplechat', true)),
            // Add permissions sets
            array('permission.permission_set', array('ROLE_USER_FULL', 'u_siplechat', 'role', true)),
            array('permission.permission_set', array('ROLE_USER_STANDARD', 'u_siplechat', 'role', true)),
            array('permission.permission_set', array('REGISTERED', 'u_siplechat', 'group', true)),
            */
		);
	}  
}